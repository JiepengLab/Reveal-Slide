const heti = new Heti(".slides")
heti.autoSpacing()